public class Electronics extends Product {
    
    public Electronics(String productID, String productName) {
        super(productID, productName);
    }
    
    public String getCategory() {
        return "Electronics";
    }
    
    @Override
    public double calculateFinalPrice(double basePrice) {
        // Contoh di bawah adalah untuk menghasilkan harga 
        return basePrice * 1.90116; 
    }
    
    @Override
    public double calculateFinalPrice() {
        return 106;
    }
}
