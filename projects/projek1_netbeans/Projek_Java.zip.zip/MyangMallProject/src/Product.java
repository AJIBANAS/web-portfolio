
public class Product {
    protected String productID;
    protected String productName;

    public Product(String productID, String productName) {
        this.productID = productID;
        this.productName = productName;
    }

    public String getCategoryID() {
        return "General Product";
    }

    // Kaedah asal untuk diketepikan (overridden) atau dimuatlebih (overloaded)
    public double calculateFinalPrice(double basePrice) {
        return basePrice;
    }

    // Kaedah overloaded (tanpa parameter basePrice) 
    public double calculateFinalPrice() {
        return 0.0; // Nilai lalai (default)
    }
}

