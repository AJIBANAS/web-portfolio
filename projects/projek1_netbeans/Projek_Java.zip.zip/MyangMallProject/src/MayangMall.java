
public class MayangMall {

    public static void displayProductDetails(Product product, double basePrice) {
        // Cuba dapatkan kategori secara dinamik 
        String category = "Unknown";
        if (product instanceof Groceries) category = ((Groceries) product).getCategory();
        else if (product instanceof Electronics) category = ((Electronics) product).getCategory();
        else if (product instanceof Clothing) category = ((Clothing) product).getCategory();

        System.out.println("Category: " + category);
        System.out.println("Product ID: " + product.productID);
        System.out.println("Name: " + product.productName);
        
        // Format to exactly two decimal places
        System.out.printf("Final Price: RM%.2f\n\n", product.calculateFinalPrice(basePrice));
    }

    public static void main(String[] args) {
        // Instantiate one object for each Product type
        Electronics elec = new Electronics("E101", "Smartphone");
        Clothing cloth = new Clothing("C202", " T-Shirt Polo");
        Groceries groc = new Groceries("G303", "Apple 1kg");

        // Display a header
        System.out.println("========= E-Commerce Pricing System =========");
        
        // Invoke displayProductDetails for Electronics, Clothing, and Groceries
        displayProductDetails(elec, 1200.00);
        displayProductDetails(cloth, 150.00);
        displayProductDetails(groc, 45.00);

        // Display a header
        System.out.println("===== Default Base Price Calculation =====");
        // Cetak harga menggunakan overloaded method 
        System.out.printf("Electronics Final Price: RM%.2f\n", elec.calculateFinalPrice());
        System.out.printf("Clothing Final Price: RM%.2f\n", cloth.calculateFinalPrice());
        System.out.printf("Groceries Final Price: RM%.2f\n", groc.calculateFinalPrice());
    }
}