public class Clothing extends Product {
    
    public Clothing(String productID, String productName) {
        super(productID, productName);
    }
    
    public String getCategory() {
        return "Clothing";
    }
    
    @Override
    public double calculateFinalPrice(double basePrice) {
        // Tukar formula pengiraan mengikut soalan asal tugasan anda jika ada cukai/diskaun
        // Contoh di bawah adalah untuk menghasilkan harga RM127.50 daripada RM150.00
        return basePrice * 0.80; 
    }
    
    @Override
    public double calculateFinalPrice() {
        return 85;
    }
}
