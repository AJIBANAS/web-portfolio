
public class Groceries extends Product {

    // 2. Sediakan constructor 
    public Groceries(String productID, String productName) {
        super(productID, productName); // Memanggil constructor milik kelas Product
    }

    // 3. Override kaedah getCategory() untuk memulangkan String "Groceries"
    public String getCategory() {
        return "Groceries";
    }

    // 4. Override kaedah calculateFinalPrice(double)
    
    @Override
    public double calculateFinalPrice(double basePrice) {
        return basePrice + 5.00;
    }
    
    // 5. Override kaedah overloaded calculateFinalPrice() tanpa parameter (untuk bahagian default base price)
    @Override
    public double calculateFinalPrice() {
        return 105; 
    }
}
